﻿namespace SE.PL
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            this.lblLogo = new System.Windows.Forms.Label();
            this.tabCnt = new System.Windows.Forms.TabControl();
            this.tpHome = new System.Windows.Forms.TabPage();
            this.picboxHomeAdd = new System.Windows.Forms.PictureBox();
            this.tpElectronics = new System.Windows.Forms.TabPage();
            this.lblElecCategoryID = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panelElecCart = new System.Windows.Forms.Panel();
            this.txtElecBillDate = new System.Windows.Forms.TextBox();
            this.txtElecTotal = new System.Windows.Forms.TextBox();
            this.txtElecQuantity = new System.Windows.Forms.TextBox();
            this.txtElecPrice = new System.Windows.Forms.TextBox();
            this.txtElecPID = new System.Windows.Forms.TextBox();
            this.btnElecBuy = new System.Windows.Forms.Button();
            this.grpBoxElecSA = new System.Windows.Forms.GroupBox();
            this.cmbElecSAState = new System.Windows.Forms.ComboBox();
            this.txtElecSAPincode = new System.Windows.Forms.TextBox();
            this.txtElecSACity = new System.Windows.Forms.TextBox();
            this.txtElecSARoomNo = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.grpBoxElecBA = new System.Windows.Forms.GroupBox();
            this.cmbElecBAState = new System.Windows.Forms.ComboBox();
            this.txtElecBAPincode = new System.Windows.Forms.TextBox();
            this.txtElecBACity = new System.Windows.Forms.TextBox();
            this.txtElecBARoomNo = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelElecProductDesc = new System.Windows.Forms.Panel();
            this.btnElecAddToCart = new System.Windows.Forms.Button();
            this.picboxElec = new System.Windows.Forms.PictureBox();
            this.txtElecDesc = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbElecProduct = new System.Windows.Forms.ComboBox();
            this.lblElecProduct = new System.Windows.Forms.Label();
            this.lblElecCategory = new System.Windows.Forms.Label();
            this.cmbElecCategory = new System.Windows.Forms.ComboBox();
            this.tpHomeAppliances = new System.Windows.Forms.TabPage();
            this.lblHACategoryID = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panelHACart = new System.Windows.Forms.Panel();
            this.txtHABillDate = new System.Windows.Forms.TextBox();
            this.txtHATotal = new System.Windows.Forms.TextBox();
            this.txtHAQuantity = new System.Windows.Forms.TextBox();
            this.txtHAPrice = new System.Windows.Forms.TextBox();
            this.txtHAPID = new System.Windows.Forms.TextBox();
            this.btnHABuy = new System.Windows.Forms.Button();
            this.grpBoxHASA = new System.Windows.Forms.GroupBox();
            this.cmbHASAState = new System.Windows.Forms.ComboBox();
            this.txtHASAPincode = new System.Windows.Forms.TextBox();
            this.txtHASACity = new System.Windows.Forms.TextBox();
            this.txtHASARoomNo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.grpBoxHABA = new System.Windows.Forms.GroupBox();
            this.cmbHABAState = new System.Windows.Forms.ComboBox();
            this.txtHABAPincode = new System.Windows.Forms.TextBox();
            this.txtHABACity = new System.Windows.Forms.TextBox();
            this.txtHABARoomNo = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.panelHAProductDesc = new System.Windows.Forms.Panel();
            this.btnHAAddToCart = new System.Windows.Forms.Button();
            this.picboxHA = new System.Windows.Forms.PictureBox();
            this.txtHADesc = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.cmbHAProduct = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.cmbHACategory = new System.Windows.Forms.ComboBox();
            this.tpMen = new System.Windows.Forms.TabPage();
            this.lblMenCategoryID = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panelMenCart = new System.Windows.Forms.Panel();
            this.txtMenBilDate = new System.Windows.Forms.TextBox();
            this.txtMenTotal = new System.Windows.Forms.TextBox();
            this.txtMenQuantity = new System.Windows.Forms.TextBox();
            this.txtMenPrice = new System.Windows.Forms.TextBox();
            this.txtMenPID = new System.Windows.Forms.TextBox();
            this.btnMenBuy = new System.Windows.Forms.Button();
            this.grpBoxMenSA = new System.Windows.Forms.GroupBox();
            this.cmbMenSAState = new System.Windows.Forms.ComboBox();
            this.txtMenSAPincode = new System.Windows.Forms.TextBox();
            this.txtMenSACity = new System.Windows.Forms.TextBox();
            this.txtMenSARoomNo = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.grpBoxMenBA = new System.Windows.Forms.GroupBox();
            this.cmbMenBAState = new System.Windows.Forms.ComboBox();
            this.txtMenBAPincode = new System.Windows.Forms.TextBox();
            this.txtMenBACity = new System.Windows.Forms.TextBox();
            this.txtMenBARoomNo = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.panelMenProductDesc = new System.Windows.Forms.Panel();
            this.btnMenAddToCart = new System.Windows.Forms.Button();
            this.picboxMen = new System.Windows.Forms.PictureBox();
            this.txtMenDesc = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.cmbMenProduct = new System.Windows.Forms.ComboBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.cmbMenCategory = new System.Windows.Forms.ComboBox();
            this.tpWomen = new System.Windows.Forms.TabPage();
            this.lblWomenCategoryID = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panelWomenCart = new System.Windows.Forms.Panel();
            this.txtWomenBillDate = new System.Windows.Forms.TextBox();
            this.txtWomenTotal = new System.Windows.Forms.TextBox();
            this.txtWomenQuantity = new System.Windows.Forms.TextBox();
            this.txtWomenPrice = new System.Windows.Forms.TextBox();
            this.txtWomenPID = new System.Windows.Forms.TextBox();
            this.btnWomenBuy = new System.Windows.Forms.Button();
            this.grpBoxWomenSA = new System.Windows.Forms.GroupBox();
            this.cmbWomenSAState = new System.Windows.Forms.ComboBox();
            this.txtWomenSAPincode = new System.Windows.Forms.TextBox();
            this.txtWomenSACity = new System.Windows.Forms.TextBox();
            this.txtWomenSARoomNo = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.grpBoxWomenBA = new System.Windows.Forms.GroupBox();
            this.cmbWomenBAState = new System.Windows.Forms.ComboBox();
            this.txtWomenBAPincode = new System.Windows.Forms.TextBox();
            this.txtWomenBACity = new System.Windows.Forms.TextBox();
            this.txtWomenBARoomNo = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.panelWomenProductDesc = new System.Windows.Forms.Panel();
            this.btnWomenAddToCart = new System.Windows.Forms.Button();
            this.picboxWomen = new System.Windows.Forms.PictureBox();
            this.txtWomenDesc = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.cmbWomenProduct = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.cmbWomenCategory = new System.Windows.Forms.ComboBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblUserName = new System.Windows.Forms.Label();
            this.linlabLogin = new System.Windows.Forms.LinkLabel();
            this.linlabLogOut = new System.Windows.Forms.LinkLabel();
            this.lblUID = new System.Windows.Forms.Label();
            this.tabCnt.SuspendLayout();
            this.tpHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxHomeAdd)).BeginInit();
            this.tpElectronics.SuspendLayout();
            this.panelElecCart.SuspendLayout();
            this.grpBoxElecSA.SuspendLayout();
            this.grpBoxElecBA.SuspendLayout();
            this.panelElecProductDesc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxElec)).BeginInit();
            this.tpHomeAppliances.SuspendLayout();
            this.panelHACart.SuspendLayout();
            this.grpBoxHASA.SuspendLayout();
            this.grpBoxHABA.SuspendLayout();
            this.panelHAProductDesc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxHA)).BeginInit();
            this.tpMen.SuspendLayout();
            this.panelMenCart.SuspendLayout();
            this.grpBoxMenSA.SuspendLayout();
            this.grpBoxMenBA.SuspendLayout();
            this.panelMenProductDesc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxMen)).BeginInit();
            this.tpWomen.SuspendLayout();
            this.panelWomenCart.SuspendLayout();
            this.grpBoxWomenSA.SuspendLayout();
            this.grpBoxWomenBA.SuspendLayout();
            this.panelWomenProductDesc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxWomen)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLogo
            // 
            this.lblLogo.AutoSize = true;
            this.lblLogo.BackColor = System.Drawing.Color.Transparent;
            this.lblLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogo.Location = new System.Drawing.Point(54, 50);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(120, 29);
            this.lblLogo.TabIndex = 2;
            this.lblLogo.Text = "Shopeasy";
            // 
            // tabCnt
            // 
            this.tabCnt.Controls.Add(this.tpHome);
            this.tabCnt.Controls.Add(this.tpElectronics);
            this.tabCnt.Controls.Add(this.tpHomeAppliances);
            this.tabCnt.Controls.Add(this.tpMen);
            this.tabCnt.Controls.Add(this.tpWomen);
            this.tabCnt.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCnt.Location = new System.Drawing.Point(197, 50);
            this.tabCnt.Name = "tabCnt";
            this.tabCnt.SelectedIndex = 0;
            this.tabCnt.Size = new System.Drawing.Size(957, 628);
            this.tabCnt.TabIndex = 3;
            // 
            // tpHome
            // 
            this.tpHome.Controls.Add(this.picboxHomeAdd);
            this.tpHome.Location = new System.Drawing.Point(4, 30);
            this.tpHome.Name = "tpHome";
            this.tpHome.Size = new System.Drawing.Size(949, 594);
            this.tpHome.TabIndex = 4;
            this.tpHome.Text = "Home";
            this.tpHome.UseVisualStyleBackColor = true;
            // 
            // picboxHomeAdd
            // 
            this.picboxHomeAdd.Image = ((System.Drawing.Image)(resources.GetObject("picboxHomeAdd.Image")));
            this.picboxHomeAdd.Location = new System.Drawing.Point(30, 108);
            this.picboxHomeAdd.Name = "picboxHomeAdd";
            this.picboxHomeAdd.Size = new System.Drawing.Size(888, 366);
            this.picboxHomeAdd.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picboxHomeAdd.TabIndex = 0;
            this.picboxHomeAdd.TabStop = false;
            // 
            // tpElectronics
            // 
            this.tpElectronics.Controls.Add(this.lblElecCategoryID);
            this.tpElectronics.Controls.Add(this.label5);
            this.tpElectronics.Controls.Add(this.panelElecCart);
            this.tpElectronics.Controls.Add(this.panelElecProductDesc);
            this.tpElectronics.Controls.Add(this.cmbElecProduct);
            this.tpElectronics.Controls.Add(this.lblElecProduct);
            this.tpElectronics.Controls.Add(this.lblElecCategory);
            this.tpElectronics.Controls.Add(this.cmbElecCategory);
            this.tpElectronics.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tpElectronics.Location = new System.Drawing.Point(4, 30);
            this.tpElectronics.Name = "tpElectronics";
            this.tpElectronics.Padding = new System.Windows.Forms.Padding(3);
            this.tpElectronics.Size = new System.Drawing.Size(949, 594);
            this.tpElectronics.TabIndex = 0;
            this.tpElectronics.Text = "Electronics";
            this.tpElectronics.UseVisualStyleBackColor = true;
            // 
            // lblElecCategoryID
            // 
            this.lblElecCategoryID.AutoSize = true;
            this.lblElecCategoryID.Location = new System.Drawing.Point(246, 16);
            this.lblElecCategoryID.Name = "lblElecCategoryID";
            this.lblElecCategoryID.Size = new System.Drawing.Size(0, 31);
            this.lblElecCategoryID.TabIndex = 7;
            this.lblElecCategoryID.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(141, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 24);
            this.label5.TabIndex = 6;
            this.label5.Text = "Cart";
            // 
            // panelElecCart
            // 
            this.panelElecCart.AutoScroll = true;
            this.panelElecCart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelElecCart.Controls.Add(this.txtElecBillDate);
            this.panelElecCart.Controls.Add(this.txtElecTotal);
            this.panelElecCart.Controls.Add(this.txtElecQuantity);
            this.panelElecCart.Controls.Add(this.txtElecPrice);
            this.panelElecCart.Controls.Add(this.txtElecPID);
            this.panelElecCart.Controls.Add(this.btnElecBuy);
            this.panelElecCart.Controls.Add(this.grpBoxElecSA);
            this.panelElecCart.Controls.Add(this.grpBoxElecBA);
            this.panelElecCart.Controls.Add(this.label23);
            this.panelElecCart.Controls.Add(this.label22);
            this.panelElecCart.Controls.Add(this.label6);
            this.panelElecCart.Controls.Add(this.label2);
            this.panelElecCart.Controls.Add(this.label1);
            this.panelElecCart.Location = new System.Drawing.Point(7, 149);
            this.panelElecCart.Name = "panelElecCart";
            this.panelElecCart.Size = new System.Drawing.Size(345, 429);
            this.panelElecCart.TabIndex = 5;
            this.panelElecCart.Visible = false;
            // 
            // txtElecBillDate
            // 
            this.txtElecBillDate.Enabled = false;
            this.txtElecBillDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtElecBillDate.Location = new System.Drawing.Point(91, 150);
            this.txtElecBillDate.Name = "txtElecBillDate";
            this.txtElecBillDate.Size = new System.Drawing.Size(228, 26);
            this.txtElecBillDate.TabIndex = 15;
            // 
            // txtElecTotal
            // 
            this.txtElecTotal.Enabled = false;
            this.txtElecTotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtElecTotal.Location = new System.Drawing.Point(91, 109);
            this.txtElecTotal.Name = "txtElecTotal";
            this.txtElecTotal.Size = new System.Drawing.Size(228, 26);
            this.txtElecTotal.TabIndex = 14;
            // 
            // txtElecQuantity
            // 
            this.txtElecQuantity.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtElecQuantity.Location = new System.Drawing.Point(91, 71);
            this.txtElecQuantity.Name = "txtElecQuantity";
            this.txtElecQuantity.Size = new System.Drawing.Size(228, 26);
            this.txtElecQuantity.TabIndex = 12;
            this.txtElecQuantity.Leave += new System.EventHandler(this.txtElecQuantity_Leave);
            // 
            // txtElecPrice
            // 
            this.txtElecPrice.Enabled = false;
            this.txtElecPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtElecPrice.Location = new System.Drawing.Point(91, 39);
            this.txtElecPrice.Name = "txtElecPrice";
            this.txtElecPrice.Size = new System.Drawing.Size(228, 26);
            this.txtElecPrice.TabIndex = 11;
            // 
            // txtElecPID
            // 
            this.txtElecPID.Enabled = false;
            this.txtElecPID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtElecPID.Location = new System.Drawing.Point(91, 7);
            this.txtElecPID.Name = "txtElecPID";
            this.txtElecPID.Size = new System.Drawing.Size(228, 26);
            this.txtElecPID.TabIndex = 10;
            // 
            // btnElecBuy
            // 
            this.btnElecBuy.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElecBuy.Location = new System.Drawing.Point(6, 530);
            this.btnElecBuy.Name = "btnElecBuy";
            this.btnElecBuy.Size = new System.Drawing.Size(333, 32);
            this.btnElecBuy.TabIndex = 9;
            this.btnElecBuy.Text = "Buy";
            this.btnElecBuy.UseVisualStyleBackColor = true;
            this.btnElecBuy.Click += new System.EventHandler(this.btnElecBuy_Click);
            // 
            // grpBoxElecSA
            // 
            this.grpBoxElecSA.Controls.Add(this.cmbElecSAState);
            this.grpBoxElecSA.Controls.Add(this.txtElecSAPincode);
            this.grpBoxElecSA.Controls.Add(this.txtElecSACity);
            this.grpBoxElecSA.Controls.Add(this.txtElecSARoomNo);
            this.grpBoxElecSA.Controls.Add(this.label28);
            this.grpBoxElecSA.Controls.Add(this.label29);
            this.grpBoxElecSA.Controls.Add(this.label30);
            this.grpBoxElecSA.Controls.Add(this.label31);
            this.grpBoxElecSA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxElecSA.Location = new System.Drawing.Point(6, 362);
            this.grpBoxElecSA.Name = "grpBoxElecSA";
            this.grpBoxElecSA.Size = new System.Drawing.Size(333, 156);
            this.grpBoxElecSA.TabIndex = 8;
            this.grpBoxElecSA.TabStop = false;
            this.grpBoxElecSA.Text = "Shipping Address";
            // 
            // cmbElecSAState
            // 
            this.cmbElecSAState.FormattingEnabled = true;
            this.cmbElecSAState.Items.AddRange(new object[] {
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu & Kashmir",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura ",
            "Uttar Pradesh",
            "West Bengal ",
            "Chhattisgarh",
            "Uttarakhand",
            "Jharkhand",
            "Telangana"});
            this.cmbElecSAState.Location = new System.Drawing.Point(90, 90);
            this.cmbElecSAState.Name = "cmbElecSAState";
            this.cmbElecSAState.Size = new System.Drawing.Size(223, 27);
            this.cmbElecSAState.TabIndex = 7;
            // 
            // txtElecSAPincode
            // 
            this.txtElecSAPincode.Location = new System.Drawing.Point(90, 124);
            this.txtElecSAPincode.Name = "txtElecSAPincode";
            this.txtElecSAPincode.Size = new System.Drawing.Size(223, 26);
            this.txtElecSAPincode.TabIndex = 6;
            // 
            // txtElecSACity
            // 
            this.txtElecSACity.Location = new System.Drawing.Point(90, 60);
            this.txtElecSACity.Name = "txtElecSACity";
            this.txtElecSACity.Size = new System.Drawing.Size(223, 26);
            this.txtElecSACity.TabIndex = 5;
            // 
            // txtElecSARoomNo
            // 
            this.txtElecSARoomNo.Location = new System.Drawing.Point(90, 23);
            this.txtElecSARoomNo.Name = "txtElecSARoomNo";
            this.txtElecSARoomNo.Size = new System.Drawing.Size(223, 26);
            this.txtElecSARoomNo.TabIndex = 4;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(10, 127);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(58, 19);
            this.label28.TabIndex = 3;
            this.label28.Text = "Pincode";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(10, 98);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(40, 19);
            this.label29.TabIndex = 2;
            this.label29.Text = "State";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(10, 67);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(37, 19);
            this.label30.TabIndex = 1;
            this.label30.Text = "City.";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(10, 30);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 19);
            this.label31.TabIndex = 0;
            this.label31.Text = "Room No.";
            // 
            // grpBoxElecBA
            // 
            this.grpBoxElecBA.Controls.Add(this.cmbElecBAState);
            this.grpBoxElecBA.Controls.Add(this.txtElecBAPincode);
            this.grpBoxElecBA.Controls.Add(this.txtElecBACity);
            this.grpBoxElecBA.Controls.Add(this.txtElecBARoomNo);
            this.grpBoxElecBA.Controls.Add(this.label27);
            this.grpBoxElecBA.Controls.Add(this.label26);
            this.grpBoxElecBA.Controls.Add(this.label25);
            this.grpBoxElecBA.Controls.Add(this.label24);
            this.grpBoxElecBA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxElecBA.Location = new System.Drawing.Point(6, 195);
            this.grpBoxElecBA.Name = "grpBoxElecBA";
            this.grpBoxElecBA.Size = new System.Drawing.Size(333, 156);
            this.grpBoxElecBA.TabIndex = 7;
            this.grpBoxElecBA.TabStop = false;
            this.grpBoxElecBA.Text = "Billing Address";
            // 
            // cmbElecBAState
            // 
            this.cmbElecBAState.FormattingEnabled = true;
            this.cmbElecBAState.Items.AddRange(new object[] {
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu & Kashmir",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura ",
            "Uttar Pradesh",
            "West Bengal ",
            "Chhattisgarh",
            "Uttarakhand",
            "Jharkhand",
            "Telangana"});
            this.cmbElecBAState.Location = new System.Drawing.Point(90, 90);
            this.cmbElecBAState.Name = "cmbElecBAState";
            this.cmbElecBAState.Size = new System.Drawing.Size(223, 27);
            this.cmbElecBAState.TabIndex = 7;
            this.cmbElecBAState.Leave += new System.EventHandler(this.cmbElecBAState_Leave);
            // 
            // txtElecBAPincode
            // 
            this.txtElecBAPincode.Location = new System.Drawing.Point(90, 124);
            this.txtElecBAPincode.Name = "txtElecBAPincode";
            this.txtElecBAPincode.Size = new System.Drawing.Size(223, 26);
            this.txtElecBAPincode.TabIndex = 6;
            this.txtElecBAPincode.Leave += new System.EventHandler(this.txtElecBAPincode_Leave);
            // 
            // txtElecBACity
            // 
            this.txtElecBACity.Location = new System.Drawing.Point(90, 60);
            this.txtElecBACity.Name = "txtElecBACity";
            this.txtElecBACity.Size = new System.Drawing.Size(223, 26);
            this.txtElecBACity.TabIndex = 5;
            this.txtElecBACity.Leave += new System.EventHandler(this.txtElecBACity_Leave);
            // 
            // txtElecBARoomNo
            // 
            this.txtElecBARoomNo.Location = new System.Drawing.Point(90, 23);
            this.txtElecBARoomNo.Name = "txtElecBARoomNo";
            this.txtElecBARoomNo.Size = new System.Drawing.Size(223, 26);
            this.txtElecBARoomNo.TabIndex = 4;
            this.txtElecBARoomNo.Leave += new System.EventHandler(this.txtElecBARoomNo_Leave);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(10, 127);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(58, 19);
            this.label27.TabIndex = 3;
            this.label27.Text = "Pincode";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 98);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 19);
            this.label26.TabIndex = 2;
            this.label26.Text = "State";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(10, 67);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(37, 19);
            this.label25.TabIndex = 1;
            this.label25.Text = "City.";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(10, 30);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(74, 19);
            this.label24.TabIndex = 0;
            this.label24.Text = "Room No.";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(8, 14);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 19);
            this.label23.TabIndex = 6;
            this.label23.Text = "Product ID";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(10, 153);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 19);
            this.label22.TabIndex = 5;
            this.label22.Text = "Bill Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 19);
            this.label6.TabIndex = 4;
            this.label6.Text = "Total";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Quantity";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Price";
            // 
            // panelElecProductDesc
            // 
            this.panelElecProductDesc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelElecProductDesc.Controls.Add(this.btnElecAddToCart);
            this.panelElecProductDesc.Controls.Add(this.picboxElec);
            this.panelElecProductDesc.Controls.Add(this.txtElecDesc);
            this.panelElecProductDesc.Controls.Add(this.label4);
            this.panelElecProductDesc.Location = new System.Drawing.Point(358, 14);
            this.panelElecProductDesc.Name = "panelElecProductDesc";
            this.panelElecProductDesc.Size = new System.Drawing.Size(583, 567);
            this.panelElecProductDesc.TabIndex = 4;
            // 
            // btnElecAddToCart
            // 
            this.btnElecAddToCart.Font = new System.Drawing.Font("Times New Roman", 14.25F);
            this.btnElecAddToCart.Location = new System.Drawing.Point(236, 486);
            this.btnElecAddToCart.Name = "btnElecAddToCart";
            this.btnElecAddToCart.Size = new System.Drawing.Size(165, 40);
            this.btnElecAddToCart.TabIndex = 3;
            this.btnElecAddToCart.Text = "Add to Cart";
            this.btnElecAddToCart.UseVisualStyleBackColor = true;
            this.btnElecAddToCart.Click += new System.EventHandler(this.btnElecAddToCart_Click);
            // 
            // picboxElec
            // 
            this.picboxElec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picboxElec.Location = new System.Drawing.Point(74, 40);
            this.picboxElec.Name = "picboxElec";
            this.picboxElec.Size = new System.Drawing.Size(434, 251);
            this.picboxElec.TabIndex = 2;
            this.picboxElec.TabStop = false;
            // 
            // txtElecDesc
            // 
            this.txtElecDesc.Location = new System.Drawing.Point(74, 297);
            this.txtElecDesc.Multiline = true;
            this.txtElecDesc.Name = "txtElecDesc";
            this.txtElecDesc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtElecDesc.Size = new System.Drawing.Size(434, 163);
            this.txtElecDesc.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(223, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "Product Description";
            // 
            // cmbElecProduct
            // 
            this.cmbElecProduct.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbElecProduct.FormattingEnabled = true;
            this.cmbElecProduct.Location = new System.Drawing.Point(103, 68);
            this.cmbElecProduct.Name = "cmbElecProduct";
            this.cmbElecProduct.Size = new System.Drawing.Size(137, 27);
            this.cmbElecProduct.TabIndex = 3;
            this.cmbElecProduct.SelectedValueChanged += new System.EventHandler(this.cmbElecProduct_SelectedValueChanged);
            // 
            // lblElecProduct
            // 
            this.lblElecProduct.AutoSize = true;
            this.lblElecProduct.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElecProduct.Location = new System.Drawing.Point(15, 68);
            this.lblElecProduct.Name = "lblElecProduct";
            this.lblElecProduct.Size = new System.Drawing.Size(57, 19);
            this.lblElecProduct.TabIndex = 2;
            this.lblElecProduct.Text = "Product";
            // 
            // lblElecCategory
            // 
            this.lblElecCategory.AutoSize = true;
            this.lblElecCategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElecCategory.Location = new System.Drawing.Point(15, 27);
            this.lblElecCategory.Name = "lblElecCategory";
            this.lblElecCategory.Size = new System.Drawing.Size(65, 19);
            this.lblElecCategory.TabIndex = 1;
            this.lblElecCategory.Text = "Category";
            // 
            // cmbElecCategory
            // 
            this.cmbElecCategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbElecCategory.FormattingEnabled = true;
            this.cmbElecCategory.Location = new System.Drawing.Point(103, 19);
            this.cmbElecCategory.Name = "cmbElecCategory";
            this.cmbElecCategory.Size = new System.Drawing.Size(137, 27);
            this.cmbElecCategory.TabIndex = 0;
            this.cmbElecCategory.SelectedValueChanged += new System.EventHandler(this.cmbElecCategory_SelectedValueChanged);
            // 
            // tpHomeAppliances
            // 
            this.tpHomeAppliances.Controls.Add(this.lblHACategoryID);
            this.tpHomeAppliances.Controls.Add(this.label7);
            this.tpHomeAppliances.Controls.Add(this.panelHACart);
            this.tpHomeAppliances.Controls.Add(this.panelHAProductDesc);
            this.tpHomeAppliances.Controls.Add(this.cmbHAProduct);
            this.tpHomeAppliances.Controls.Add(this.label44);
            this.tpHomeAppliances.Controls.Add(this.label45);
            this.tpHomeAppliances.Controls.Add(this.cmbHACategory);
            this.tpHomeAppliances.Location = new System.Drawing.Point(4, 30);
            this.tpHomeAppliances.Name = "tpHomeAppliances";
            this.tpHomeAppliances.Padding = new System.Windows.Forms.Padding(3);
            this.tpHomeAppliances.Size = new System.Drawing.Size(949, 594);
            this.tpHomeAppliances.TabIndex = 1;
            this.tpHomeAppliances.Text = "Home Appliances";
            this.tpHomeAppliances.UseVisualStyleBackColor = true;
            // 
            // lblHACategoryID
            // 
            this.lblHACategoryID.AutoSize = true;
            this.lblHACategoryID.Location = new System.Drawing.Point(246, 21);
            this.lblHACategoryID.Name = "lblHACategoryID";
            this.lblHACategoryID.Size = new System.Drawing.Size(0, 21);
            this.lblHACategoryID.TabIndex = 14;
            this.lblHACategoryID.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(141, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 24);
            this.label7.TabIndex = 13;
            this.label7.Text = "Cart";
            // 
            // panelHACart
            // 
            this.panelHACart.AutoScroll = true;
            this.panelHACart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelHACart.Controls.Add(this.txtHABillDate);
            this.panelHACart.Controls.Add(this.txtHATotal);
            this.panelHACart.Controls.Add(this.txtHAQuantity);
            this.panelHACart.Controls.Add(this.txtHAPrice);
            this.panelHACart.Controls.Add(this.txtHAPID);
            this.panelHACart.Controls.Add(this.btnHABuy);
            this.panelHACart.Controls.Add(this.grpBoxHASA);
            this.panelHACart.Controls.Add(this.grpBoxHABA);
            this.panelHACart.Controls.Add(this.label37);
            this.panelHACart.Controls.Add(this.label38);
            this.panelHACart.Controls.Add(this.label39);
            this.panelHACart.Controls.Add(this.label41);
            this.panelHACart.Controls.Add(this.label42);
            this.panelHACart.Location = new System.Drawing.Point(7, 149);
            this.panelHACart.Name = "panelHACart";
            this.panelHACart.Size = new System.Drawing.Size(345, 429);
            this.panelHACart.TabIndex = 12;
            this.panelHACart.Visible = false;
            // 
            // txtHABillDate
            // 
            this.txtHABillDate.Enabled = false;
            this.txtHABillDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHABillDate.Location = new System.Drawing.Point(91, 153);
            this.txtHABillDate.Name = "txtHABillDate";
            this.txtHABillDate.Size = new System.Drawing.Size(228, 26);
            this.txtHABillDate.TabIndex = 15;
            // 
            // txtHATotal
            // 
            this.txtHATotal.Enabled = false;
            this.txtHATotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHATotal.Location = new System.Drawing.Point(91, 111);
            this.txtHATotal.Name = "txtHATotal";
            this.txtHATotal.Size = new System.Drawing.Size(228, 26);
            this.txtHATotal.TabIndex = 14;
            // 
            // txtHAQuantity
            // 
            this.txtHAQuantity.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHAQuantity.Location = new System.Drawing.Point(91, 71);
            this.txtHAQuantity.Name = "txtHAQuantity";
            this.txtHAQuantity.Size = new System.Drawing.Size(228, 26);
            this.txtHAQuantity.TabIndex = 12;
            this.txtHAQuantity.Leave += new System.EventHandler(this.txtHAQuantity_Leave);
            // 
            // txtHAPrice
            // 
            this.txtHAPrice.Enabled = false;
            this.txtHAPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHAPrice.Location = new System.Drawing.Point(91, 39);
            this.txtHAPrice.Name = "txtHAPrice";
            this.txtHAPrice.Size = new System.Drawing.Size(228, 26);
            this.txtHAPrice.TabIndex = 11;
            // 
            // txtHAPID
            // 
            this.txtHAPID.Enabled = false;
            this.txtHAPID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHAPID.Location = new System.Drawing.Point(91, 7);
            this.txtHAPID.Name = "txtHAPID";
            this.txtHAPID.Size = new System.Drawing.Size(228, 26);
            this.txtHAPID.TabIndex = 10;
            // 
            // btnHABuy
            // 
            this.btnHABuy.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHABuy.Location = new System.Drawing.Point(6, 530);
            this.btnHABuy.Name = "btnHABuy";
            this.btnHABuy.Size = new System.Drawing.Size(333, 32);
            this.btnHABuy.TabIndex = 9;
            this.btnHABuy.Text = "Buy";
            this.btnHABuy.UseVisualStyleBackColor = true;
            this.btnHABuy.Click += new System.EventHandler(this.btnHABuy_Click);
            // 
            // grpBoxHASA
            // 
            this.grpBoxHASA.Controls.Add(this.cmbHASAState);
            this.grpBoxHASA.Controls.Add(this.txtHASAPincode);
            this.grpBoxHASA.Controls.Add(this.txtHASACity);
            this.grpBoxHASA.Controls.Add(this.txtHASARoomNo);
            this.grpBoxHASA.Controls.Add(this.label8);
            this.grpBoxHASA.Controls.Add(this.label9);
            this.grpBoxHASA.Controls.Add(this.label10);
            this.grpBoxHASA.Controls.Add(this.label32);
            this.grpBoxHASA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxHASA.Location = new System.Drawing.Point(6, 362);
            this.grpBoxHASA.Name = "grpBoxHASA";
            this.grpBoxHASA.Size = new System.Drawing.Size(333, 156);
            this.grpBoxHASA.TabIndex = 8;
            this.grpBoxHASA.TabStop = false;
            this.grpBoxHASA.Text = "Shipping Address";
            // 
            // cmbHASAState
            // 
            this.cmbHASAState.FormattingEnabled = true;
            this.cmbHASAState.Items.AddRange(new object[] {
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu & Kashmir",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura ",
            "Uttar Pradesh",
            "West Bengal ",
            "Chhattisgarh",
            "Uttarakhand",
            "Jharkhand",
            "Telangana"});
            this.cmbHASAState.Location = new System.Drawing.Point(90, 90);
            this.cmbHASAState.Name = "cmbHASAState";
            this.cmbHASAState.Size = new System.Drawing.Size(223, 27);
            this.cmbHASAState.TabIndex = 7;
            // 
            // txtHASAPincode
            // 
            this.txtHASAPincode.Location = new System.Drawing.Point(90, 124);
            this.txtHASAPincode.Name = "txtHASAPincode";
            this.txtHASAPincode.Size = new System.Drawing.Size(223, 26);
            this.txtHASAPincode.TabIndex = 6;
            // 
            // txtHASACity
            // 
            this.txtHASACity.Location = new System.Drawing.Point(90, 60);
            this.txtHASACity.Name = "txtHASACity";
            this.txtHASACity.Size = new System.Drawing.Size(223, 26);
            this.txtHASACity.TabIndex = 5;
            // 
            // txtHASARoomNo
            // 
            this.txtHASARoomNo.Location = new System.Drawing.Point(90, 23);
            this.txtHASARoomNo.Name = "txtHASARoomNo";
            this.txtHASARoomNo.Size = new System.Drawing.Size(223, 26);
            this.txtHASARoomNo.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 127);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 19);
            this.label8.TabIndex = 3;
            this.label8.Text = "Pincode";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 98);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 19);
            this.label9.TabIndex = 2;
            this.label9.Text = "State";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 19);
            this.label10.TabIndex = 1;
            this.label10.Text = "City.";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(10, 30);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(74, 19);
            this.label32.TabIndex = 0;
            this.label32.Text = "Room No.";
            // 
            // grpBoxHABA
            // 
            this.grpBoxHABA.Controls.Add(this.cmbHABAState);
            this.grpBoxHABA.Controls.Add(this.txtHABAPincode);
            this.grpBoxHABA.Controls.Add(this.txtHABACity);
            this.grpBoxHABA.Controls.Add(this.txtHABARoomNo);
            this.grpBoxHABA.Controls.Add(this.label33);
            this.grpBoxHABA.Controls.Add(this.label34);
            this.grpBoxHABA.Controls.Add(this.label35);
            this.grpBoxHABA.Controls.Add(this.label36);
            this.grpBoxHABA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxHABA.Location = new System.Drawing.Point(6, 195);
            this.grpBoxHABA.Name = "grpBoxHABA";
            this.grpBoxHABA.Size = new System.Drawing.Size(333, 156);
            this.grpBoxHABA.TabIndex = 7;
            this.grpBoxHABA.TabStop = false;
            this.grpBoxHABA.Text = "Billing Address";
            // 
            // cmbHABAState
            // 
            this.cmbHABAState.FormattingEnabled = true;
            this.cmbHABAState.Items.AddRange(new object[] {
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu & Kashmir",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura ",
            "Uttar Pradesh",
            "West Bengal ",
            "Chhattisgarh",
            "Uttarakhand",
            "Jharkhand",
            "Telangana"});
            this.cmbHABAState.Location = new System.Drawing.Point(90, 90);
            this.cmbHABAState.Name = "cmbHABAState";
            this.cmbHABAState.Size = new System.Drawing.Size(223, 27);
            this.cmbHABAState.TabIndex = 7;
            this.cmbHABAState.Leave += new System.EventHandler(this.cmbHABAState_Leave);
            // 
            // txtHABAPincode
            // 
            this.txtHABAPincode.Location = new System.Drawing.Point(90, 124);
            this.txtHABAPincode.Name = "txtHABAPincode";
            this.txtHABAPincode.Size = new System.Drawing.Size(223, 26);
            this.txtHABAPincode.TabIndex = 6;
            this.txtHABAPincode.Leave += new System.EventHandler(this.txtHABAPincode_Leave);
            // 
            // txtHABACity
            // 
            this.txtHABACity.Location = new System.Drawing.Point(90, 60);
            this.txtHABACity.Name = "txtHABACity";
            this.txtHABACity.Size = new System.Drawing.Size(223, 26);
            this.txtHABACity.TabIndex = 5;
            this.txtHABACity.Leave += new System.EventHandler(this.txtHABACity_Leave);
            // 
            // txtHABARoomNo
            // 
            this.txtHABARoomNo.Location = new System.Drawing.Point(90, 23);
            this.txtHABARoomNo.Name = "txtHABARoomNo";
            this.txtHABARoomNo.Size = new System.Drawing.Size(223, 26);
            this.txtHABARoomNo.TabIndex = 4;
            this.txtHABARoomNo.Leave += new System.EventHandler(this.txtHABARoomNo_Leave);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(10, 127);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(58, 19);
            this.label33.TabIndex = 3;
            this.label33.Text = "Pincode";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(10, 98);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(40, 19);
            this.label34.TabIndex = 2;
            this.label34.Text = "State";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(10, 67);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(37, 19);
            this.label35.TabIndex = 1;
            this.label35.Text = "City.";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(10, 30);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(74, 19);
            this.label36.TabIndex = 0;
            this.label36.Text = "Room No.";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(8, 14);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 19);
            this.label37.TabIndex = 6;
            this.label37.Text = "Product ID";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(10, 156);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(61, 19);
            this.label38.TabIndex = 5;
            this.label38.Text = "Bill Date";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(9, 116);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(39, 19);
            this.label39.TabIndex = 4;
            this.label39.Text = "Total";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(8, 76);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(60, 19);
            this.label41.TabIndex = 2;
            this.label41.Text = "Quantity";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(8, 46);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(40, 19);
            this.label42.TabIndex = 1;
            this.label42.Text = "Price";
            // 
            // panelHAProductDesc
            // 
            this.panelHAProductDesc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelHAProductDesc.Controls.Add(this.btnHAAddToCart);
            this.panelHAProductDesc.Controls.Add(this.picboxHA);
            this.panelHAProductDesc.Controls.Add(this.txtHADesc);
            this.panelHAProductDesc.Controls.Add(this.label43);
            this.panelHAProductDesc.Location = new System.Drawing.Point(358, 14);
            this.panelHAProductDesc.Name = "panelHAProductDesc";
            this.panelHAProductDesc.Size = new System.Drawing.Size(583, 567);
            this.panelHAProductDesc.TabIndex = 11;
            // 
            // btnHAAddToCart
            // 
            this.btnHAAddToCart.Location = new System.Drawing.Point(236, 486);
            this.btnHAAddToCart.Name = "btnHAAddToCart";
            this.btnHAAddToCart.Size = new System.Drawing.Size(165, 40);
            this.btnHAAddToCart.TabIndex = 3;
            this.btnHAAddToCart.Text = "Add to Cart";
            this.btnHAAddToCart.UseVisualStyleBackColor = true;
            this.btnHAAddToCart.Click += new System.EventHandler(this.btnHAAddToCart_Click);
            // 
            // picboxHA
            // 
            this.picboxHA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picboxHA.Location = new System.Drawing.Point(74, 40);
            this.picboxHA.Name = "picboxHA";
            this.picboxHA.Size = new System.Drawing.Size(434, 251);
            this.picboxHA.TabIndex = 2;
            this.picboxHA.TabStop = false;
            // 
            // txtHADesc
            // 
            this.txtHADesc.Location = new System.Drawing.Point(74, 297);
            this.txtHADesc.Multiline = true;
            this.txtHADesc.Name = "txtHADesc";
            this.txtHADesc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtHADesc.Size = new System.Drawing.Size(434, 163);
            this.txtHADesc.TabIndex = 1;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(223, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(130, 19);
            this.label43.TabIndex = 0;
            this.label43.Text = "Product Description";
            // 
            // cmbHAProduct
            // 
            this.cmbHAProduct.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbHAProduct.FormattingEnabled = true;
            this.cmbHAProduct.Location = new System.Drawing.Point(103, 68);
            this.cmbHAProduct.Name = "cmbHAProduct";
            this.cmbHAProduct.Size = new System.Drawing.Size(137, 27);
            this.cmbHAProduct.TabIndex = 10;
            this.cmbHAProduct.SelectedValueChanged += new System.EventHandler(this.cmbHAProduct_SelectedValueChanged);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(15, 68);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(57, 19);
            this.label44.TabIndex = 9;
            this.label44.Text = "Product";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(15, 27);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(65, 19);
            this.label45.TabIndex = 8;
            this.label45.Text = "Category";
            // 
            // cmbHACategory
            // 
            this.cmbHACategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbHACategory.FormattingEnabled = true;
            this.cmbHACategory.Location = new System.Drawing.Point(103, 19);
            this.cmbHACategory.Name = "cmbHACategory";
            this.cmbHACategory.Size = new System.Drawing.Size(137, 27);
            this.cmbHACategory.TabIndex = 7;
            this.cmbHACategory.SelectedValueChanged += new System.EventHandler(this.cmbHACategory_SelectedValueChanged);
            // 
            // tpMen
            // 
            this.tpMen.Controls.Add(this.lblMenCategoryID);
            this.tpMen.Controls.Add(this.label11);
            this.tpMen.Controls.Add(this.panelMenCart);
            this.tpMen.Controls.Add(this.panelMenProductDesc);
            this.tpMen.Controls.Add(this.cmbMenProduct);
            this.tpMen.Controls.Add(this.label58);
            this.tpMen.Controls.Add(this.label59);
            this.tpMen.Controls.Add(this.cmbMenCategory);
            this.tpMen.Location = new System.Drawing.Point(4, 30);
            this.tpMen.Name = "tpMen";
            this.tpMen.Size = new System.Drawing.Size(949, 594);
            this.tpMen.TabIndex = 2;
            this.tpMen.Text = "Men";
            this.tpMen.UseVisualStyleBackColor = true;
            // 
            // lblMenCategoryID
            // 
            this.lblMenCategoryID.AutoSize = true;
            this.lblMenCategoryID.Location = new System.Drawing.Point(246, 21);
            this.lblMenCategoryID.Name = "lblMenCategoryID";
            this.lblMenCategoryID.Size = new System.Drawing.Size(0, 21);
            this.lblMenCategoryID.TabIndex = 14;
            this.lblMenCategoryID.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(141, 119);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 24);
            this.label11.TabIndex = 13;
            this.label11.Text = "Cart";
            // 
            // panelMenCart
            // 
            this.panelMenCart.AutoScroll = true;
            this.panelMenCart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelMenCart.Controls.Add(this.txtMenBilDate);
            this.panelMenCart.Controls.Add(this.txtMenTotal);
            this.panelMenCart.Controls.Add(this.txtMenQuantity);
            this.panelMenCart.Controls.Add(this.txtMenPrice);
            this.panelMenCart.Controls.Add(this.txtMenPID);
            this.panelMenCart.Controls.Add(this.btnMenBuy);
            this.panelMenCart.Controls.Add(this.grpBoxMenSA);
            this.panelMenCart.Controls.Add(this.grpBoxMenBA);
            this.panelMenCart.Controls.Add(this.label51);
            this.panelMenCart.Controls.Add(this.label52);
            this.panelMenCart.Controls.Add(this.label53);
            this.panelMenCart.Controls.Add(this.label55);
            this.panelMenCart.Controls.Add(this.label56);
            this.panelMenCart.Location = new System.Drawing.Point(7, 149);
            this.panelMenCart.Name = "panelMenCart";
            this.panelMenCart.Size = new System.Drawing.Size(345, 429);
            this.panelMenCart.TabIndex = 12;
            this.panelMenCart.Visible = false;
            // 
            // txtMenBilDate
            // 
            this.txtMenBilDate.Enabled = false;
            this.txtMenBilDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMenBilDate.Location = new System.Drawing.Point(91, 164);
            this.txtMenBilDate.Name = "txtMenBilDate";
            this.txtMenBilDate.Size = new System.Drawing.Size(228, 26);
            this.txtMenBilDate.TabIndex = 15;
            // 
            // txtMenTotal
            // 
            this.txtMenTotal.Enabled = false;
            this.txtMenTotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMenTotal.Location = new System.Drawing.Point(91, 134);
            this.txtMenTotal.Name = "txtMenTotal";
            this.txtMenTotal.Size = new System.Drawing.Size(228, 26);
            this.txtMenTotal.TabIndex = 14;
            // 
            // txtMenQuantity
            // 
            this.txtMenQuantity.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMenQuantity.Location = new System.Drawing.Point(91, 71);
            this.txtMenQuantity.Name = "txtMenQuantity";
            this.txtMenQuantity.Size = new System.Drawing.Size(228, 26);
            this.txtMenQuantity.TabIndex = 12;
            this.txtMenQuantity.Leave += new System.EventHandler(this.txtMenQuantity_Leave);
            // 
            // txtMenPrice
            // 
            this.txtMenPrice.Enabled = false;
            this.txtMenPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMenPrice.Location = new System.Drawing.Point(91, 39);
            this.txtMenPrice.Name = "txtMenPrice";
            this.txtMenPrice.Size = new System.Drawing.Size(228, 26);
            this.txtMenPrice.TabIndex = 11;
            // 
            // txtMenPID
            // 
            this.txtMenPID.Enabled = false;
            this.txtMenPID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMenPID.Location = new System.Drawing.Point(91, 7);
            this.txtMenPID.Name = "txtMenPID";
            this.txtMenPID.Size = new System.Drawing.Size(228, 26);
            this.txtMenPID.TabIndex = 10;
            // 
            // btnMenBuy
            // 
            this.btnMenBuy.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenBuy.Location = new System.Drawing.Point(6, 530);
            this.btnMenBuy.Name = "btnMenBuy";
            this.btnMenBuy.Size = new System.Drawing.Size(333, 32);
            this.btnMenBuy.TabIndex = 9;
            this.btnMenBuy.Text = "Buy";
            this.btnMenBuy.UseVisualStyleBackColor = true;
            this.btnMenBuy.Click += new System.EventHandler(this.btnMenBuy_Click);
            // 
            // grpBoxMenSA
            // 
            this.grpBoxMenSA.Controls.Add(this.cmbMenSAState);
            this.grpBoxMenSA.Controls.Add(this.txtMenSAPincode);
            this.grpBoxMenSA.Controls.Add(this.txtMenSACity);
            this.grpBoxMenSA.Controls.Add(this.txtMenSARoomNo);
            this.grpBoxMenSA.Controls.Add(this.label12);
            this.grpBoxMenSA.Controls.Add(this.label13);
            this.grpBoxMenSA.Controls.Add(this.label14);
            this.grpBoxMenSA.Controls.Add(this.label46);
            this.grpBoxMenSA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxMenSA.Location = new System.Drawing.Point(6, 362);
            this.grpBoxMenSA.Name = "grpBoxMenSA";
            this.grpBoxMenSA.Size = new System.Drawing.Size(333, 156);
            this.grpBoxMenSA.TabIndex = 8;
            this.grpBoxMenSA.TabStop = false;
            this.grpBoxMenSA.Text = "Shipping Address";
            // 
            // cmbMenSAState
            // 
            this.cmbMenSAState.FormattingEnabled = true;
            this.cmbMenSAState.Items.AddRange(new object[] {
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu & Kashmir",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura ",
            "Uttar Pradesh",
            "West Bengal ",
            "Chhattisgarh",
            "Uttarakhand",
            "Jharkhand",
            "Telangana"});
            this.cmbMenSAState.Location = new System.Drawing.Point(90, 90);
            this.cmbMenSAState.Name = "cmbMenSAState";
            this.cmbMenSAState.Size = new System.Drawing.Size(223, 27);
            this.cmbMenSAState.TabIndex = 7;
            // 
            // txtMenSAPincode
            // 
            this.txtMenSAPincode.Location = new System.Drawing.Point(90, 124);
            this.txtMenSAPincode.Name = "txtMenSAPincode";
            this.txtMenSAPincode.Size = new System.Drawing.Size(223, 26);
            this.txtMenSAPincode.TabIndex = 6;
            // 
            // txtMenSACity
            // 
            this.txtMenSACity.Location = new System.Drawing.Point(90, 60);
            this.txtMenSACity.Name = "txtMenSACity";
            this.txtMenSACity.Size = new System.Drawing.Size(223, 26);
            this.txtMenSACity.TabIndex = 5;
            // 
            // txtMenSARoomNo
            // 
            this.txtMenSARoomNo.Location = new System.Drawing.Point(90, 23);
            this.txtMenSARoomNo.Name = "txtMenSARoomNo";
            this.txtMenSARoomNo.Size = new System.Drawing.Size(223, 26);
            this.txtMenSARoomNo.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 127);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 19);
            this.label12.TabIndex = 3;
            this.label12.Text = "Pincode";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(10, 98);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 19);
            this.label13.TabIndex = 2;
            this.label13.Text = "State";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(10, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 19);
            this.label14.TabIndex = 1;
            this.label14.Text = "City.";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(10, 30);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(74, 19);
            this.label46.TabIndex = 0;
            this.label46.Text = "Room No.";
            // 
            // grpBoxMenBA
            // 
            this.grpBoxMenBA.Controls.Add(this.cmbMenBAState);
            this.grpBoxMenBA.Controls.Add(this.txtMenBAPincode);
            this.grpBoxMenBA.Controls.Add(this.txtMenBACity);
            this.grpBoxMenBA.Controls.Add(this.txtMenBARoomNo);
            this.grpBoxMenBA.Controls.Add(this.label47);
            this.grpBoxMenBA.Controls.Add(this.label48);
            this.grpBoxMenBA.Controls.Add(this.label49);
            this.grpBoxMenBA.Controls.Add(this.label50);
            this.grpBoxMenBA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxMenBA.Location = new System.Drawing.Point(6, 195);
            this.grpBoxMenBA.Name = "grpBoxMenBA";
            this.grpBoxMenBA.Size = new System.Drawing.Size(333, 156);
            this.grpBoxMenBA.TabIndex = 7;
            this.grpBoxMenBA.TabStop = false;
            this.grpBoxMenBA.Text = "Billing Address";
            // 
            // cmbMenBAState
            // 
            this.cmbMenBAState.FormattingEnabled = true;
            this.cmbMenBAState.Items.AddRange(new object[] {
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu & Kashmir",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura ",
            "Uttar Pradesh",
            "West Bengal ",
            "Chhattisgarh",
            "Uttarakhand",
            "Jharkhand",
            "Telangana"});
            this.cmbMenBAState.Location = new System.Drawing.Point(90, 90);
            this.cmbMenBAState.Name = "cmbMenBAState";
            this.cmbMenBAState.Size = new System.Drawing.Size(223, 27);
            this.cmbMenBAState.TabIndex = 7;
            this.cmbMenBAState.Leave += new System.EventHandler(this.cmbMenBAState_Leave);
            // 
            // txtMenBAPincode
            // 
            this.txtMenBAPincode.Location = new System.Drawing.Point(90, 124);
            this.txtMenBAPincode.Name = "txtMenBAPincode";
            this.txtMenBAPincode.Size = new System.Drawing.Size(223, 26);
            this.txtMenBAPincode.TabIndex = 6;
            this.txtMenBAPincode.Leave += new System.EventHandler(this.txtMenBAPincode_Leave);
            // 
            // txtMenBACity
            // 
            this.txtMenBACity.Location = new System.Drawing.Point(90, 60);
            this.txtMenBACity.Name = "txtMenBACity";
            this.txtMenBACity.Size = new System.Drawing.Size(223, 26);
            this.txtMenBACity.TabIndex = 5;
            this.txtMenBACity.Leave += new System.EventHandler(this.txtMenBACity_Leave);
            // 
            // txtMenBARoomNo
            // 
            this.txtMenBARoomNo.Location = new System.Drawing.Point(90, 23);
            this.txtMenBARoomNo.Name = "txtMenBARoomNo";
            this.txtMenBARoomNo.Size = new System.Drawing.Size(223, 26);
            this.txtMenBARoomNo.TabIndex = 4;
            this.txtMenBARoomNo.Layout += new System.Windows.Forms.LayoutEventHandler(this.txtMenBARoomNo_Layout);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(10, 127);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(58, 19);
            this.label47.TabIndex = 3;
            this.label47.Text = "Pincode";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(10, 98);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(40, 19);
            this.label48.TabIndex = 2;
            this.label48.Text = "State";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(10, 67);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(37, 19);
            this.label49.TabIndex = 1;
            this.label49.Text = "City.";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(10, 30);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(74, 19);
            this.label50.TabIndex = 0;
            this.label50.Text = "Room No.";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(8, 14);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(77, 19);
            this.label51.TabIndex = 6;
            this.label51.Text = "Product ID";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(10, 167);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(61, 19);
            this.label52.TabIndex = 5;
            this.label52.Text = "Bill Date";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(9, 139);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(39, 19);
            this.label53.TabIndex = 4;
            this.label53.Text = "Total";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(8, 76);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(60, 19);
            this.label55.TabIndex = 2;
            this.label55.Text = "Quantity";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(8, 46);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(40, 19);
            this.label56.TabIndex = 1;
            this.label56.Text = "Price";
            // 
            // panelMenProductDesc
            // 
            this.panelMenProductDesc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelMenProductDesc.Controls.Add(this.btnMenAddToCart);
            this.panelMenProductDesc.Controls.Add(this.picboxMen);
            this.panelMenProductDesc.Controls.Add(this.txtMenDesc);
            this.panelMenProductDesc.Controls.Add(this.label57);
            this.panelMenProductDesc.Location = new System.Drawing.Point(358, 14);
            this.panelMenProductDesc.Name = "panelMenProductDesc";
            this.panelMenProductDesc.Size = new System.Drawing.Size(583, 567);
            this.panelMenProductDesc.TabIndex = 11;
            // 
            // btnMenAddToCart
            // 
            this.btnMenAddToCart.Location = new System.Drawing.Point(236, 486);
            this.btnMenAddToCart.Name = "btnMenAddToCart";
            this.btnMenAddToCart.Size = new System.Drawing.Size(165, 40);
            this.btnMenAddToCart.TabIndex = 3;
            this.btnMenAddToCart.Text = "Add to Cart";
            this.btnMenAddToCart.UseVisualStyleBackColor = true;
            this.btnMenAddToCart.Click += new System.EventHandler(this.btnMenAddToCart_Click);
            // 
            // picboxMen
            // 
            this.picboxMen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picboxMen.Location = new System.Drawing.Point(74, 40);
            this.picboxMen.Name = "picboxMen";
            this.picboxMen.Size = new System.Drawing.Size(434, 251);
            this.picboxMen.TabIndex = 2;
            this.picboxMen.TabStop = false;
            // 
            // txtMenDesc
            // 
            this.txtMenDesc.Location = new System.Drawing.Point(74, 297);
            this.txtMenDesc.Multiline = true;
            this.txtMenDesc.Name = "txtMenDesc";
            this.txtMenDesc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtMenDesc.Size = new System.Drawing.Size(434, 163);
            this.txtMenDesc.TabIndex = 1;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(223, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(130, 19);
            this.label57.TabIndex = 0;
            this.label57.Text = "Product Description";
            // 
            // cmbMenProduct
            // 
            this.cmbMenProduct.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMenProduct.FormattingEnabled = true;
            this.cmbMenProduct.Location = new System.Drawing.Point(103, 68);
            this.cmbMenProduct.Name = "cmbMenProduct";
            this.cmbMenProduct.Size = new System.Drawing.Size(137, 27);
            this.cmbMenProduct.TabIndex = 10;
            this.cmbMenProduct.SelectedValueChanged += new System.EventHandler(this.cmbMenProduct_SelectedValueChanged);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(15, 68);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(57, 19);
            this.label58.TabIndex = 9;
            this.label58.Text = "Product";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(15, 27);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(65, 19);
            this.label59.TabIndex = 8;
            this.label59.Text = "Category";
            // 
            // cmbMenCategory
            // 
            this.cmbMenCategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMenCategory.FormattingEnabled = true;
            this.cmbMenCategory.Location = new System.Drawing.Point(103, 19);
            this.cmbMenCategory.Name = "cmbMenCategory";
            this.cmbMenCategory.Size = new System.Drawing.Size(137, 27);
            this.cmbMenCategory.TabIndex = 7;
            this.cmbMenCategory.SelectedValueChanged += new System.EventHandler(this.cmbMenCategory_SelectedValueChanged);
            // 
            // tpWomen
            // 
            this.tpWomen.Controls.Add(this.lblWomenCategoryID);
            this.tpWomen.Controls.Add(this.label15);
            this.tpWomen.Controls.Add(this.panelWomenCart);
            this.tpWomen.Controls.Add(this.panelWomenProductDesc);
            this.tpWomen.Controls.Add(this.cmbWomenProduct);
            this.tpWomen.Controls.Add(this.label69);
            this.tpWomen.Controls.Add(this.label70);
            this.tpWomen.Controls.Add(this.cmbWomenCategory);
            this.tpWomen.Location = new System.Drawing.Point(4, 30);
            this.tpWomen.Name = "tpWomen";
            this.tpWomen.Size = new System.Drawing.Size(949, 594);
            this.tpWomen.TabIndex = 3;
            this.tpWomen.Text = "Women";
            this.tpWomen.UseVisualStyleBackColor = true;
            // 
            // lblWomenCategoryID
            // 
            this.lblWomenCategoryID.AutoSize = true;
            this.lblWomenCategoryID.Location = new System.Drawing.Point(246, 21);
            this.lblWomenCategoryID.Name = "lblWomenCategoryID";
            this.lblWomenCategoryID.Size = new System.Drawing.Size(0, 21);
            this.lblWomenCategoryID.TabIndex = 14;
            this.lblWomenCategoryID.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(141, 119);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 24);
            this.label15.TabIndex = 13;
            this.label15.Text = "Cart";
            // 
            // panelWomenCart
            // 
            this.panelWomenCart.AutoScroll = true;
            this.panelWomenCart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelWomenCart.Controls.Add(this.txtWomenBillDate);
            this.panelWomenCart.Controls.Add(this.txtWomenTotal);
            this.panelWomenCart.Controls.Add(this.txtWomenQuantity);
            this.panelWomenCart.Controls.Add(this.txtWomenPrice);
            this.panelWomenCart.Controls.Add(this.txtWomenPID);
            this.panelWomenCart.Controls.Add(this.btnWomenBuy);
            this.panelWomenCart.Controls.Add(this.grpBoxWomenSA);
            this.panelWomenCart.Controls.Add(this.grpBoxWomenBA);
            this.panelWomenCart.Controls.Add(this.label62);
            this.panelWomenCart.Controls.Add(this.label63);
            this.panelWomenCart.Controls.Add(this.label64);
            this.panelWomenCart.Controls.Add(this.label66);
            this.panelWomenCart.Controls.Add(this.label67);
            this.panelWomenCart.Location = new System.Drawing.Point(7, 149);
            this.panelWomenCart.Name = "panelWomenCart";
            this.panelWomenCart.Size = new System.Drawing.Size(345, 429);
            this.panelWomenCart.TabIndex = 12;
            this.panelWomenCart.Visible = false;
            // 
            // txtWomenBillDate
            // 
            this.txtWomenBillDate.Enabled = false;
            this.txtWomenBillDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWomenBillDate.Location = new System.Drawing.Point(94, 145);
            this.txtWomenBillDate.Name = "txtWomenBillDate";
            this.txtWomenBillDate.Size = new System.Drawing.Size(228, 26);
            this.txtWomenBillDate.TabIndex = 15;
            // 
            // txtWomenTotal
            // 
            this.txtWomenTotal.Enabled = false;
            this.txtWomenTotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWomenTotal.Location = new System.Drawing.Point(94, 110);
            this.txtWomenTotal.Name = "txtWomenTotal";
            this.txtWomenTotal.Size = new System.Drawing.Size(228, 26);
            this.txtWomenTotal.TabIndex = 14;
            // 
            // txtWomenQuantity
            // 
            this.txtWomenQuantity.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWomenQuantity.Location = new System.Drawing.Point(91, 71);
            this.txtWomenQuantity.Name = "txtWomenQuantity";
            this.txtWomenQuantity.Size = new System.Drawing.Size(228, 26);
            this.txtWomenQuantity.TabIndex = 12;
            this.txtWomenQuantity.Leave += new System.EventHandler(this.txtWomenQuantity_Leave);
            // 
            // txtWomenPrice
            // 
            this.txtWomenPrice.Enabled = false;
            this.txtWomenPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWomenPrice.Location = new System.Drawing.Point(91, 39);
            this.txtWomenPrice.Name = "txtWomenPrice";
            this.txtWomenPrice.Size = new System.Drawing.Size(228, 26);
            this.txtWomenPrice.TabIndex = 11;
            // 
            // txtWomenPID
            // 
            this.txtWomenPID.Enabled = false;
            this.txtWomenPID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWomenPID.Location = new System.Drawing.Point(91, 7);
            this.txtWomenPID.Name = "txtWomenPID";
            this.txtWomenPID.Size = new System.Drawing.Size(228, 26);
            this.txtWomenPID.TabIndex = 10;
            // 
            // btnWomenBuy
            // 
            this.btnWomenBuy.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWomenBuy.Location = new System.Drawing.Point(6, 530);
            this.btnWomenBuy.Name = "btnWomenBuy";
            this.btnWomenBuy.Size = new System.Drawing.Size(333, 32);
            this.btnWomenBuy.TabIndex = 9;
            this.btnWomenBuy.Text = "Buy";
            this.btnWomenBuy.UseVisualStyleBackColor = true;
            this.btnWomenBuy.Click += new System.EventHandler(this.btnWomenBuy_Click);
            // 
            // grpBoxWomenSA
            // 
            this.grpBoxWomenSA.Controls.Add(this.cmbWomenSAState);
            this.grpBoxWomenSA.Controls.Add(this.txtWomenSAPincode);
            this.grpBoxWomenSA.Controls.Add(this.txtWomenSACity);
            this.grpBoxWomenSA.Controls.Add(this.txtWomenSARoomNo);
            this.grpBoxWomenSA.Controls.Add(this.label16);
            this.grpBoxWomenSA.Controls.Add(this.label17);
            this.grpBoxWomenSA.Controls.Add(this.label18);
            this.grpBoxWomenSA.Controls.Add(this.label19);
            this.grpBoxWomenSA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxWomenSA.Location = new System.Drawing.Point(10, 333);
            this.grpBoxWomenSA.Name = "grpBoxWomenSA";
            this.grpBoxWomenSA.Size = new System.Drawing.Size(333, 156);
            this.grpBoxWomenSA.TabIndex = 8;
            this.grpBoxWomenSA.TabStop = false;
            this.grpBoxWomenSA.Text = "Shipping Address";
            // 
            // cmbWomenSAState
            // 
            this.cmbWomenSAState.FormattingEnabled = true;
            this.cmbWomenSAState.Items.AddRange(new object[] {
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu & Kashmir",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura ",
            "Uttar Pradesh",
            "West Bengal ",
            "Chhattisgarh",
            "Uttarakhand",
            "Jharkhand",
            "Telangana"});
            this.cmbWomenSAState.Location = new System.Drawing.Point(90, 90);
            this.cmbWomenSAState.Name = "cmbWomenSAState";
            this.cmbWomenSAState.Size = new System.Drawing.Size(223, 27);
            this.cmbWomenSAState.TabIndex = 7;
            // 
            // txtWomenSAPincode
            // 
            this.txtWomenSAPincode.Location = new System.Drawing.Point(90, 124);
            this.txtWomenSAPincode.Name = "txtWomenSAPincode";
            this.txtWomenSAPincode.Size = new System.Drawing.Size(223, 26);
            this.txtWomenSAPincode.TabIndex = 6;
            // 
            // txtWomenSACity
            // 
            this.txtWomenSACity.Location = new System.Drawing.Point(90, 60);
            this.txtWomenSACity.Name = "txtWomenSACity";
            this.txtWomenSACity.Size = new System.Drawing.Size(223, 26);
            this.txtWomenSACity.TabIndex = 5;
            // 
            // txtWomenSARoomNo
            // 
            this.txtWomenSARoomNo.Location = new System.Drawing.Point(90, 23);
            this.txtWomenSARoomNo.Name = "txtWomenSARoomNo";
            this.txtWomenSARoomNo.Size = new System.Drawing.Size(223, 26);
            this.txtWomenSARoomNo.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 127);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 19);
            this.label16.TabIndex = 3;
            this.label16.Text = "Pincode";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 98);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 19);
            this.label17.TabIndex = 2;
            this.label17.Text = "State";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 67);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 19);
            this.label18.TabIndex = 1;
            this.label18.Text = "City.";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 19);
            this.label19.TabIndex = 0;
            this.label19.Text = "Room No.";
            // 
            // grpBoxWomenBA
            // 
            this.grpBoxWomenBA.Controls.Add(this.cmbWomenBAState);
            this.grpBoxWomenBA.Controls.Add(this.txtWomenBAPincode);
            this.grpBoxWomenBA.Controls.Add(this.txtWomenBACity);
            this.grpBoxWomenBA.Controls.Add(this.txtWomenBARoomNo);
            this.grpBoxWomenBA.Controls.Add(this.label20);
            this.grpBoxWomenBA.Controls.Add(this.label21);
            this.grpBoxWomenBA.Controls.Add(this.label60);
            this.grpBoxWomenBA.Controls.Add(this.label61);
            this.grpBoxWomenBA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxWomenBA.Location = new System.Drawing.Point(6, 177);
            this.grpBoxWomenBA.Name = "grpBoxWomenBA";
            this.grpBoxWomenBA.Size = new System.Drawing.Size(333, 156);
            this.grpBoxWomenBA.TabIndex = 7;
            this.grpBoxWomenBA.TabStop = false;
            this.grpBoxWomenBA.Text = "Billing Address";
            // 
            // cmbWomenBAState
            // 
            this.cmbWomenBAState.FormattingEnabled = true;
            this.cmbWomenBAState.Items.AddRange(new object[] {
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu & Kashmir",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura ",
            "Uttar Pradesh",
            "West Bengal ",
            "Chhattisgarh",
            "Uttarakhand",
            "Jharkhand",
            "Telangana"});
            this.cmbWomenBAState.Location = new System.Drawing.Point(90, 90);
            this.cmbWomenBAState.Name = "cmbWomenBAState";
            this.cmbWomenBAState.Size = new System.Drawing.Size(223, 27);
            this.cmbWomenBAState.TabIndex = 7;
            this.cmbWomenBAState.Leave += new System.EventHandler(this.cmbWomenBAState_Leave);
            // 
            // txtWomenBAPincode
            // 
            this.txtWomenBAPincode.Location = new System.Drawing.Point(90, 124);
            this.txtWomenBAPincode.Name = "txtWomenBAPincode";
            this.txtWomenBAPincode.Size = new System.Drawing.Size(223, 26);
            this.txtWomenBAPincode.TabIndex = 6;
            this.txtWomenBAPincode.Leave += new System.EventHandler(this.txtWomenBAPincode_Leave);
            // 
            // txtWomenBACity
            // 
            this.txtWomenBACity.Location = new System.Drawing.Point(90, 60);
            this.txtWomenBACity.Name = "txtWomenBACity";
            this.txtWomenBACity.Size = new System.Drawing.Size(223, 26);
            this.txtWomenBACity.TabIndex = 5;
            this.txtWomenBACity.Leave += new System.EventHandler(this.txtWomenBACity_Leave);
            // 
            // txtWomenBARoomNo
            // 
            this.txtWomenBARoomNo.Location = new System.Drawing.Point(90, 23);
            this.txtWomenBARoomNo.Name = "txtWomenBARoomNo";
            this.txtWomenBARoomNo.Size = new System.Drawing.Size(223, 26);
            this.txtWomenBARoomNo.TabIndex = 4;
            this.txtWomenBARoomNo.Leave += new System.EventHandler(this.txtWomenBARoomNo_Leave);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(10, 127);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(58, 19);
            this.label20.TabIndex = 3;
            this.label20.Text = "Pincode";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(10, 98);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(40, 19);
            this.label21.TabIndex = 2;
            this.label21.Text = "State";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(10, 67);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(37, 19);
            this.label60.TabIndex = 1;
            this.label60.Text = "City.";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(10, 30);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(74, 19);
            this.label61.TabIndex = 0;
            this.label61.Text = "Room No.";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(8, 14);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(77, 19);
            this.label62.TabIndex = 6;
            this.label62.Text = "Product ID";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(10, 148);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(61, 19);
            this.label63.TabIndex = 5;
            this.label63.Text = "Bill Date";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(8, 113);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(39, 19);
            this.label64.TabIndex = 4;
            this.label64.Text = "Total";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(8, 76);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(60, 19);
            this.label66.TabIndex = 2;
            this.label66.Text = "Quantity";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(8, 46);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(40, 19);
            this.label67.TabIndex = 1;
            this.label67.Text = "Price";
            // 
            // panelWomenProductDesc
            // 
            this.panelWomenProductDesc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelWomenProductDesc.Controls.Add(this.btnWomenAddToCart);
            this.panelWomenProductDesc.Controls.Add(this.picboxWomen);
            this.panelWomenProductDesc.Controls.Add(this.txtWomenDesc);
            this.panelWomenProductDesc.Controls.Add(this.label68);
            this.panelWomenProductDesc.Location = new System.Drawing.Point(358, 14);
            this.panelWomenProductDesc.Name = "panelWomenProductDesc";
            this.panelWomenProductDesc.Size = new System.Drawing.Size(583, 567);
            this.panelWomenProductDesc.TabIndex = 11;
            // 
            // btnWomenAddToCart
            // 
            this.btnWomenAddToCart.Location = new System.Drawing.Point(236, 486);
            this.btnWomenAddToCart.Name = "btnWomenAddToCart";
            this.btnWomenAddToCart.Size = new System.Drawing.Size(165, 40);
            this.btnWomenAddToCart.TabIndex = 3;
            this.btnWomenAddToCart.Text = "Add to Cart";
            this.btnWomenAddToCart.UseVisualStyleBackColor = true;
            this.btnWomenAddToCart.Click += new System.EventHandler(this.btnWomenAddToCart_Click);
            // 
            // picboxWomen
            // 
            this.picboxWomen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picboxWomen.Location = new System.Drawing.Point(74, 40);
            this.picboxWomen.Name = "picboxWomen";
            this.picboxWomen.Size = new System.Drawing.Size(434, 251);
            this.picboxWomen.TabIndex = 2;
            this.picboxWomen.TabStop = false;
            // 
            // txtWomenDesc
            // 
            this.txtWomenDesc.Location = new System.Drawing.Point(74, 297);
            this.txtWomenDesc.Multiline = true;
            this.txtWomenDesc.Name = "txtWomenDesc";
            this.txtWomenDesc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtWomenDesc.Size = new System.Drawing.Size(434, 163);
            this.txtWomenDesc.TabIndex = 1;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(223, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(130, 19);
            this.label68.TabIndex = 0;
            this.label68.Text = "Product Description";
            // 
            // cmbWomenProduct
            // 
            this.cmbWomenProduct.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWomenProduct.FormattingEnabled = true;
            this.cmbWomenProduct.Location = new System.Drawing.Point(103, 68);
            this.cmbWomenProduct.Name = "cmbWomenProduct";
            this.cmbWomenProduct.Size = new System.Drawing.Size(137, 27);
            this.cmbWomenProduct.TabIndex = 10;
            this.cmbWomenProduct.SelectedValueChanged += new System.EventHandler(this.cmbWomenProduct_SelectedValueChanged);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(15, 68);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(57, 19);
            this.label69.TabIndex = 9;
            this.label69.Text = "Product";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(15, 27);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(65, 19);
            this.label70.TabIndex = 8;
            this.label70.Text = "Category";
            // 
            // cmbWomenCategory
            // 
            this.cmbWomenCategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWomenCategory.FormattingEnabled = true;
            this.cmbWomenCategory.Location = new System.Drawing.Point(103, 19);
            this.cmbWomenCategory.Name = "cmbWomenCategory";
            this.cmbWomenCategory.Size = new System.Drawing.Size(137, 27);
            this.cmbWomenCategory.TabIndex = 7;
            this.cmbWomenCategory.SelectedValueChanged += new System.EventHandler(this.cmbWomenCategory_SelectedValueChanged);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.BackColor = System.Drawing.Color.Transparent;
            this.lblUserName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.Location = new System.Drawing.Point(934, 11);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(0, 19);
            this.lblUserName.TabIndex = 9;
            this.lblUserName.Click += new System.EventHandler(this.lblUser_Click);
            // 
            // linlabLogin
            // 
            this.linlabLogin.AutoSize = true;
            this.linlabLogin.BackColor = System.Drawing.Color.Transparent;
            this.linlabLogin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linlabLogin.Location = new System.Drawing.Point(1089, 9);
            this.linlabLogin.Name = "linlabLogin";
            this.linlabLogin.Size = new System.Drawing.Size(53, 21);
            this.linlabLogin.TabIndex = 8;
            this.linlabLogin.TabStop = true;
            this.linlabLogin.Text = "Login";
            this.linlabLogin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linlabLogin_LinkClicked);
            // 
            // linlabLogOut
            // 
            this.linlabLogOut.AutoSize = true;
            this.linlabLogOut.BackColor = System.Drawing.Color.Transparent;
            this.linlabLogOut.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linlabLogOut.Location = new System.Drawing.Point(1090, 9);
            this.linlabLogOut.Name = "linlabLogOut";
            this.linlabLogOut.Size = new System.Drawing.Size(64, 21);
            this.linlabLogOut.TabIndex = 7;
            this.linlabLogOut.TabStop = true;
            this.linlabLogOut.Text = "Logout";
            this.linlabLogOut.Visible = false;
            this.linlabLogOut.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linlabLogOut_LinkClicked);
            // 
            // lblUID
            // 
            this.lblUID.AutoSize = true;
            this.lblUID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUID.Location = new System.Drawing.Point(873, 15);
            this.lblUID.Name = "lblUID";
            this.lblUID.Size = new System.Drawing.Size(0, 19);
            this.lblUID.TabIndex = 10;
            this.lblUID.Visible = false;
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1184, 741);
            this.Controls.Add(this.lblUID);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.linlabLogin);
            this.Controls.Add(this.linlabLogOut);
            this.Controls.Add(this.tabCnt);
            this.Controls.Add(this.lblLogo);
            this.Name = "HomePage";
            this.Text = "HomePage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.HomePage_Activated);
            this.Load += new System.EventHandler(this.HomePage_Load);
            this.tabCnt.ResumeLayout(false);
            this.tpHome.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picboxHomeAdd)).EndInit();
            this.tpElectronics.ResumeLayout(false);
            this.tpElectronics.PerformLayout();
            this.panelElecCart.ResumeLayout(false);
            this.panelElecCart.PerformLayout();
            this.grpBoxElecSA.ResumeLayout(false);
            this.grpBoxElecSA.PerformLayout();
            this.grpBoxElecBA.ResumeLayout(false);
            this.grpBoxElecBA.PerformLayout();
            this.panelElecProductDesc.ResumeLayout(false);
            this.panelElecProductDesc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxElec)).EndInit();
            this.tpHomeAppliances.ResumeLayout(false);
            this.tpHomeAppliances.PerformLayout();
            this.panelHACart.ResumeLayout(false);
            this.panelHACart.PerformLayout();
            this.grpBoxHASA.ResumeLayout(false);
            this.grpBoxHASA.PerformLayout();
            this.grpBoxHABA.ResumeLayout(false);
            this.grpBoxHABA.PerformLayout();
            this.panelHAProductDesc.ResumeLayout(false);
            this.panelHAProductDesc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxHA)).EndInit();
            this.tpMen.ResumeLayout(false);
            this.tpMen.PerformLayout();
            this.panelMenCart.ResumeLayout(false);
            this.panelMenCart.PerformLayout();
            this.grpBoxMenSA.ResumeLayout(false);
            this.grpBoxMenSA.PerformLayout();
            this.grpBoxMenBA.ResumeLayout(false);
            this.grpBoxMenBA.PerformLayout();
            this.panelMenProductDesc.ResumeLayout(false);
            this.panelMenProductDesc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxMen)).EndInit();
            this.tpWomen.ResumeLayout(false);
            this.tpWomen.PerformLayout();
            this.panelWomenCart.ResumeLayout(false);
            this.panelWomenCart.PerformLayout();
            this.grpBoxWomenSA.ResumeLayout(false);
            this.grpBoxWomenSA.PerformLayout();
            this.grpBoxWomenBA.ResumeLayout(false);
            this.grpBoxWomenBA.PerformLayout();
            this.panelWomenProductDesc.ResumeLayout(false);
            this.panelWomenProductDesc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxWomen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.TabControl tabCnt;
        private System.Windows.Forms.TabPage tpHome;
        private System.Windows.Forms.PictureBox picboxHomeAdd;
        private System.Windows.Forms.TabPage tpElectronics;
        private System.Windows.Forms.Panel panelElecCart;
        private System.Windows.Forms.Panel panelElecProductDesc;
        private System.Windows.Forms.Button btnElecAddToCart;
        private System.Windows.Forms.PictureBox picboxElec;
        private System.Windows.Forms.TextBox txtElecDesc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbElecProduct;
        private System.Windows.Forms.Label lblElecProduct;
        private System.Windows.Forms.Label lblElecCategory;
        private System.Windows.Forms.ComboBox cmbElecCategory;
        private System.Windows.Forms.TabPage tpHomeAppliances;
        private System.Windows.Forms.TabPage tpMen;
        private System.Windows.Forms.TabPage tpWomen;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.LinkLabel linlabLogin;
        private System.Windows.Forms.LinkLabel linlabLogOut;
        private System.Windows.Forms.Button btnElecBuy;
        private System.Windows.Forms.GroupBox grpBoxElecSA;
        private System.Windows.Forms.ComboBox cmbElecSAState;
        private System.Windows.Forms.TextBox txtElecSAPincode;
        private System.Windows.Forms.TextBox txtElecSACity;
        private System.Windows.Forms.TextBox txtElecSARoomNo;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox grpBoxElecBA;
        private System.Windows.Forms.ComboBox cmbElecBAState;
        private System.Windows.Forms.TextBox txtElecBAPincode;
        private System.Windows.Forms.TextBox txtElecBACity;
        private System.Windows.Forms.TextBox txtElecBARoomNo;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtElecBillDate;
        private System.Windows.Forms.TextBox txtElecTotal;
        private System.Windows.Forms.TextBox txtElecQuantity;
        private System.Windows.Forms.TextBox txtElecPrice;
        private System.Windows.Forms.TextBox txtElecPID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panelHACart;
        private System.Windows.Forms.TextBox txtHABillDate;
        private System.Windows.Forms.TextBox txtHATotal;
        private System.Windows.Forms.TextBox txtHAQuantity;
        private System.Windows.Forms.TextBox txtHAPrice;
        private System.Windows.Forms.TextBox txtHAPID;
        private System.Windows.Forms.Button btnHABuy;
        private System.Windows.Forms.GroupBox grpBoxHASA;
        private System.Windows.Forms.ComboBox cmbHASAState;
        private System.Windows.Forms.TextBox txtHASAPincode;
        private System.Windows.Forms.TextBox txtHASACity;
        private System.Windows.Forms.TextBox txtHASARoomNo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox grpBoxHABA;
        private System.Windows.Forms.ComboBox cmbHABAState;
        private System.Windows.Forms.TextBox txtHABAPincode;
        private System.Windows.Forms.TextBox txtHABACity;
        private System.Windows.Forms.TextBox txtHABARoomNo;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panelHAProductDesc;
        private System.Windows.Forms.Button btnHAAddToCart;
        private System.Windows.Forms.PictureBox picboxHA;
        private System.Windows.Forms.TextBox txtHADesc;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox cmbHAProduct;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox cmbHACategory;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panelMenCart;
        private System.Windows.Forms.TextBox txtMenBilDate;
        private System.Windows.Forms.TextBox txtMenTotal;
        private System.Windows.Forms.TextBox txtMenQuantity;
        private System.Windows.Forms.TextBox txtMenPrice;
        private System.Windows.Forms.TextBox txtMenPID;
        private System.Windows.Forms.Button btnMenBuy;
        private System.Windows.Forms.GroupBox grpBoxMenSA;
        private System.Windows.Forms.ComboBox cmbMenSAState;
        private System.Windows.Forms.TextBox txtMenSAPincode;
        private System.Windows.Forms.TextBox txtMenSACity;
        private System.Windows.Forms.TextBox txtMenSARoomNo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.GroupBox grpBoxMenBA;
        private System.Windows.Forms.ComboBox cmbMenBAState;
        private System.Windows.Forms.TextBox txtMenBAPincode;
        private System.Windows.Forms.TextBox txtMenBACity;
        private System.Windows.Forms.TextBox txtMenBARoomNo;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Panel panelMenProductDesc;
        private System.Windows.Forms.Button btnMenAddToCart;
        private System.Windows.Forms.PictureBox picboxMen;
        private System.Windows.Forms.TextBox txtMenDesc;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ComboBox cmbMenProduct;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.ComboBox cmbMenCategory;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panelWomenCart;
        private System.Windows.Forms.TextBox txtWomenBillDate;
        private System.Windows.Forms.TextBox txtWomenTotal;
        private System.Windows.Forms.TextBox txtWomenQuantity;
        private System.Windows.Forms.TextBox txtWomenPrice;
        private System.Windows.Forms.TextBox txtWomenPID;
        private System.Windows.Forms.Button btnWomenBuy;
        private System.Windows.Forms.GroupBox grpBoxWomenSA;
        private System.Windows.Forms.ComboBox cmbWomenSAState;
        private System.Windows.Forms.TextBox txtWomenSAPincode;
        private System.Windows.Forms.TextBox txtWomenSACity;
        private System.Windows.Forms.TextBox txtWomenSARoomNo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox grpBoxWomenBA;
        private System.Windows.Forms.ComboBox cmbWomenBAState;
        private System.Windows.Forms.TextBox txtWomenBAPincode;
        private System.Windows.Forms.TextBox txtWomenBACity;
        private System.Windows.Forms.TextBox txtWomenBARoomNo;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Panel panelWomenProductDesc;
        private System.Windows.Forms.Button btnWomenAddToCart;
        private System.Windows.Forms.PictureBox picboxWomen;
        private System.Windows.Forms.TextBox txtWomenDesc;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.ComboBox cmbWomenProduct;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.ComboBox cmbWomenCategory;
        private System.Windows.Forms.Label lblUID;
        private System.Windows.Forms.Label lblElecCategoryID;
        private System.Windows.Forms.Label lblHACategoryID;
        private System.Windows.Forms.Label lblMenCategoryID;
        private System.Windows.Forms.Label lblWomenCategoryID;
    }
}

