﻿namespace SE.PL
{
    partial class SupplierLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSupplierLogin = new System.Windows.Forms.Button();
            this.txtSupPassword = new System.Windows.Forms.TextBox();
            this.txtSupUserName = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblLogin = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnSupplierLogin);
            this.panel1.Controls.Add(this.txtSupPassword);
            this.panel1.Controls.Add(this.txtSupUserName);
            this.panel1.Controls.Add(this.lblPassword);
            this.panel1.Controls.Add(this.lblUserName);
            this.panel1.Controls.Add(this.lblLogin);
            this.panel1.Location = new System.Drawing.Point(425, 199);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(334, 365);
            this.panel1.TabIndex = 2;
            this.panel1.Tag = "";
            // 
            // btnSupplierLogin
            // 
            this.btnSupplierLogin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSupplierLogin.Location = new System.Drawing.Point(132, 229);
            this.btnSupplierLogin.Name = "btnSupplierLogin";
            this.btnSupplierLogin.Size = new System.Drawing.Size(67, 30);
            this.btnSupplierLogin.TabIndex = 5;
            this.btnSupplierLogin.Text = "Login";
            this.btnSupplierLogin.UseVisualStyleBackColor = true;
            this.btnSupplierLogin.Click += new System.EventHandler(this.btnSupplierLogin_Click);
            // 
            // txtSupPassword
            // 
            this.txtSupPassword.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSupPassword.Location = new System.Drawing.Point(124, 160);
            this.txtSupPassword.Name = "txtSupPassword";
            this.txtSupPassword.PasswordChar = '*';
            this.txtSupPassword.Size = new System.Drawing.Size(179, 29);
            this.txtSupPassword.TabIndex = 4;
            // 
            // txtSupUserName
            // 
            this.txtSupUserName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSupUserName.Location = new System.Drawing.Point(124, 95);
            this.txtSupUserName.Name = "txtSupUserName";
            this.txtSupUserName.Size = new System.Drawing.Size(179, 29);
            this.txtSupUserName.TabIndex = 3;
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(25, 158);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(84, 21);
            this.lblPassword.TabIndex = 2;
            this.lblPassword.Text = "Password";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.Location = new System.Drawing.Point(25, 94);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(93, 21);
            this.lblUserName.TabIndex = 1;
            this.lblUserName.Text = "User Name";
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogin.Location = new System.Drawing.Point(114, 13);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(103, 22);
            this.lblLogin.TabIndex = 0;
            this.lblLogin.Text = "Login Page";
            // 
            // SupplierLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 762);
            this.Controls.Add(this.panel1);
            this.Name = "SupplierLogin";
            this.Text = "SupplierLogin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSupplierLogin;
        private System.Windows.Forms.TextBox txtSupPassword;
        private System.Windows.Forms.TextBox txtSupUserName;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblLogin;
    }
}