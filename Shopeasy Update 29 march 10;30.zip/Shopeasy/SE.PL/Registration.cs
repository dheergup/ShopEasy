﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SE.Entity;
using SE.Exception;
using SE.BL;
using System.Data.SqlClient;

namespace SE.PL
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }
        CustomValidation cv = new CustomValidation();
        private void btnRegister_Click(object sender, EventArgs e)
        {
            Customer cust = new Customer();
            cust.CFName = txtFName.Text;
            cust.CLName = txtLName.Text;
            cust.Email = txtEmail.Text;
            cust.Mobile = txtMobile.Text;
            cust.UserID = txtUID.Text;
            cust.Pass = txtPass.Text;
            try
            {
                bool flag = cv.addCustomer(cust);
                if(flag)
                {
                    MessageBox.Show(txtFName.Text + " " + txtLName.Text + " \nYou are registered successfully");
                    Login lg = new Login();
                    lg.Show();
                    this.Hide();
                }
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void txtCPass_Leave(object sender, EventArgs e)
        {
            string pass = txtPass.Text;
            string cpass = txtCPass.Text;
            if (pass != cpass)
            {
                MessageBox.Show("Check Password Doesn't Match");
                txtCPass.Clear();
                txtPass.Clear();
                txtPass.Focus();
            }
        }
    }
}
