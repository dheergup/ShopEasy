﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;
using EMS.DAL;

namespace EMS.BL
{
    public class UserValidation
    {
        public static string ValidateUser(User user)
        {
            string userName = null;

            try 
            {
                userName = UserOperations.ValidateLogin(user);
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }
    }
}
