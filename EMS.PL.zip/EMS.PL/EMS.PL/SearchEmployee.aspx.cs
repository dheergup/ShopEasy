﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    public partial class SearchEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"].ToString();
                Master.LogoutVisible = true;
                Master.MenuVisible = true;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try 
            {
                int empID = Convert.ToInt32(txtEmpID.Text);
                Employee emp = EmployeeValidation.SearchEmployee(empID);
                if (emp != null)
                {
                    gvEmployee.DataSource = new List<Employee>{emp};
                    gvEmployee.DataBind();
                }
                else
                {
                    string message = "Employee not found with id : " + empID;
                    throw new EmployeeException(message);
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}