﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication2.Models;

namespace MvcApplication2.Controllers
{
    public class Default2Controller : Controller
    {
        private Training_18Jan2017_TalwadeEntities db = new Training_18Jan2017_TalwadeEntities();

        //
        // GET: /Default2/

        public ActionResult Index()
        {
            return View(db.GymManagementSystems.ToList());
        }

        //
        // GET: /Default2/Details/5

        public ActionResult Details(int id = 0)
        {
            GymManagementSystem gymmanagementsystem = db.GymManagementSystems.Find(id);
            if (gymmanagementsystem == null)
            {
                return HttpNotFound();
            }
            return View(gymmanagementsystem);
        }

        //
        // GET: /Default2/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Default2/Create

        [HttpPost]
        public ActionResult Create(GymManagementSystem gymmanagementsystem)
        {
            if (ModelState.IsValid)
            {
                db.GymManagementSystems.Add(gymmanagementsystem);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(gymmanagementsystem);
        }

        //
        // GET: /Default2/Edit/5

        public ActionResult Edit(int id = 0)
        {
            GymManagementSystem gymmanagementsystem = db.GymManagementSystems.Find(id);
            if (gymmanagementsystem == null)
            {
                return HttpNotFound();
            }
            return View(gymmanagementsystem);
        }

        //
        // POST: /Default2/Edit/5

        [HttpPost]
        public ActionResult Edit(GymManagementSystem gymmanagementsystem)
        {
            if (ModelState.IsValid)
            {
                db.Entry(gymmanagementsystem).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(gymmanagementsystem);
        }

        //
        // GET: /Default2/Delete/5

        public ActionResult Delete(int id = 0)
        {
            GymManagementSystem gymmanagementsystem = db.GymManagementSystems.Find(id);
            if (gymmanagementsystem == null)
            {
                return HttpNotFound();
            }
            return View(gymmanagementsystem);
        }

        //
        // POST: /Default2/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            GymManagementSystem gymmanagementsystem = db.GymManagementSystems.Find(id);
            db.GymManagementSystems.Remove(gymmanagementsystem);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}