﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using SE.Entity;
using SE.Exception;
using SE.DAL;
using System.IO;

namespace SE.PL
{
    public partial class HomePage : Form
    {
        private int imageNumber = 1;

        private void loadNextImage()
        {
            if (imageNumber == 4)
            {
                imageNumber = 1;
            }
            picboxHomeAdd.Load(string.Format(@".\Images\logo{0}.jpg", imageNumber));
            imageNumber++;
        }
        public HomePage()
        {
            InitializeComponent();
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {

        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            try
            {
                Operations op = new Operations();
                DataTable dt = new DataTable();
                dt = op.searchCategory("Electronics");
                DataSet ds = new DataSet();
                ds.Tables.Add(dt);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbElecCategory.Items.Add(ds.Tables[0].Rows[i][0].ToString());
                }
                dt = new DataTable();
                dt = op.searchCategory("Home Appliances");
                ds.Tables.Add(dt);
                for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                {
                    cmbHACategory.Items.Add(ds.Tables[1].Rows[i][0].ToString());
                }
                dt = new DataTable();
                dt = op.searchCategory("Men");
                ds.Tables.Add(dt);
                for (int i = 0; i < ds.Tables[2].Rows.Count; i++)
                {
                    cmbMenCategory.Items.Add(ds.Tables[2].Rows[i][0].ToString());
                }
                dt = new DataTable();
                dt = op.searchCategory("Women");
                ds.Tables.Add(dt);
                for (int i = 0; i < ds.Tables[3].Rows.Count; i++)
                {
                    cmbWomenCategory.Items.Add(ds.Tables[3].Rows[i][0].ToString());
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void HomePage_Activated(object sender, EventArgs e)
        {
            if (Login.user != null)
            {
                lblUserName.Text = Login.user;
                lblUID.Text = Login.Uid;
                lblUserName.Visible = true;
                linlabLogOut.Visible = true;
                linlabLogin.Visible = false;
            }
            else
            {
                linlabLogin.Visible = true;
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            loadNextImage();
        }

        private void linlabLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Login lg = new Login();
            lg.Show();
        }

        private void linlabLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Logged Out");
            this.tabCnt.SelectTab("tpHome");
            Login.user = null;
            lblUserName.Text = "";
            linlabLogOut.Visible = false;
            linlabLogin.Visible = true;
            HomePage hp = new HomePage();
            hp.Show();
            this.Close();
        }

        private void btnElecAddToCart_Click(object sender, EventArgs e)
        {
            if (lblUserName.Text == "")
            {
                this.Hide();
                Login lg = new Login();
                lg.Show();
            }
            else
            {
                panelElecCart.Visible = true;
                
            }
        }

        private void btnHAAddToCart_Click(object sender, EventArgs e)
        {
            if (lblUserName.Text == "")
            {
                this.Hide();
                Login lg = new Login();
                lg.Show();
            }
            else
            {
                panelHACart.Visible = true;
            }
        }

        private void btnMenAddToCart_Click(object sender, EventArgs e)
        {
            if (lblUserName.Text == "")
            {
                this.Hide();
                Login lg = new Login();
                lg.Show();
            }
            else
            {
                this.Hide();
                panelMenCart.Visible = true;
            }
        }

        private void btnWomenAddToCart_Click(object sender, EventArgs e)
        {
            if (lblUserName.Text == "")
            {
                this.Hide();
                Login lg = new Login();
                lg.Show();
            }
            else
            {
                panelWomenCart.Visible = true;
            }
        }

        private void lblUser_Click(object sender, EventArgs e)
        {

        }

        private void cmbElecCategory_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                Operations op = new Operations();
                DataTable tb = new DataTable();
                tb = op.searchProduct(cmbElecCategory.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                cmbElecProduct.Items.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbElecProduct.Items.Add(ds.Tables[0].Rows[i][1].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbHACategory_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                Operations op = new Operations();
                DataTable tb = new DataTable();
                tb = op.searchProduct(cmbHACategory.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                cmbHAProduct.Items.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbHAProduct.Items.Add(ds.Tables[0].Rows[i][1].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbMenCategory_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                Operations op = new Operations();
                DataTable tb = new DataTable();
                tb = op.searchProduct(cmbMenCategory.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                cmbMenProduct.Items.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbMenProduct.Items.Add(ds.Tables[0].Rows[i][1].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbWomenCategory_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                Operations op = new Operations();
                DataTable tb = new DataTable();
                tb = op.searchProduct(cmbWomenCategory.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                cmbWomenProduct.Items.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbWomenProduct.Items.Add(ds.Tables[0].Rows[i][1].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbElecProduct_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                Operations op = new Operations();
                DataTable tb = new DataTable();
                tb = op.getProductByName(cmbElecProduct.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtElecPID.Text = ds.Tables[0].Rows[0][0].ToString();
                txtElecPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                txtElecDesc.Text = ds.Tables[0].Rows[0][10].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                MemoryStream mem = new MemoryStream(data);
                picboxElec.Image = Image.FromStream(mem);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnElecBuy_Click(object sender, EventArgs e)
        {
            Order ord = new Order();
            ord.ODate = DateTime.Now;
            ord.CustomerID = Convert.ToInt32(lblUID.Text);
            ord.ProductID = Convert.ToInt32(txtElecPID.Text);
            ord.Price = Convert.ToInt32(txtElecPrice.Text);
            ord.Quantity = Convert.ToInt32(txtElecQuantity.Text);
            ord.Total = Convert.ToInt32(txtElecTotal.Text);
            ord.BARoomNo = txtElecBARoomNo.Text;
            ord.BACity = txtElecBACity.Text;
            ord.BAState = cmbElecBAState.SelectedItem.ToString();
            ord.BAPincode = txtElecBAPincode.Text;
            ord.SARoomNo = txtElecSARoomNo.Text;
            ord.SACity = txtElecSACity.Text;
            ord.SAState = cmbElecSAState.Text;
            ord.SAPincode = txtElecSAPincode.Text;
            Operations op = new Operations();
            try
            {
                bool flag = op.addOrder(ord);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbHAProduct_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                Operations op = new Operations();
                DataTable tb = new DataTable();
                tb = op.getProductByName(cmbHAProduct.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtHAPID.Text = ds.Tables[0].Rows[0][0].ToString();
                txtHAPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                txtHADiscount.Text = ds.Tables[0].Rows[0][7].ToString();
                txtHADesc.Text = ds.Tables[0].Rows[0][10].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                MemoryStream mem = new MemoryStream(data);
                picboxHA.Image = Image.FromStream(mem);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbMenProduct_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                Operations op = new Operations();
                DataTable tb = new DataTable();
                tb = op.getProductByName(cmbMenProduct.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtMenPID.Text = ds.Tables[0].Rows[0][0].ToString();
                txtMenPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                txtMenDiscount.Text = ds.Tables[0].Rows[0][7].ToString();
                txtMenDesc.Text = ds.Tables[0].Rows[0][10].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                MemoryStream mem = new MemoryStream(data);
                picboxMen.Image = Image.FromStream(mem);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbWomenProduct_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                Operations op = new Operations();
                DataTable tb = new DataTable();
                tb = op.getProductByName(cmbWomenProduct.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtWomenPID.Text = ds.Tables[0].Rows[0][0].ToString();
                txtWomenPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                txtWomenDiscount.Text = ds.Tables[0].Rows[0][7].ToString();
                txtWomenDesc.Text = ds.Tables[0].Rows[0][10].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                MemoryStream mem = new MemoryStream(data);
                picboxWomen.Image = Image.FromStream(mem);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtElecQuantity_Leave(object sender, EventArgs e)
        {
            txtElecTotal.Text = (Convert.ToInt32(txtElecPrice.Text)*Convert.ToInt32(txtElecQuantity.Text)).ToString();
            txtElecBillDate.Text = DateTime.Now.ToShortDateString();
        }

        private void txtElecBARoomNo_Leave(object sender, EventArgs e)
        {
            txtElecSARoomNo.Text = txtElecBARoomNo.Text;
        }

        private void txtElecBACity_Leave(object sender, EventArgs e)
        {
            txtElecSACity.Text = txtElecBACity.Text;
        }

        private void txtElecBAPincode_Leave(object sender, EventArgs e)
        {
            txtElecSAPincode.Text = txtElecBAPincode.Text;
        }

        private void cmbElecBAState_Leave(object sender, EventArgs e)
        {
            cmbElecSAState.SelectedIndex = cmbElecBAState.SelectedIndex;
        }
    }
}
