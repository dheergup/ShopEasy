﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SE.Entity;
using SE.Exception;
using SE.DAL;

namespace SE.PL
{
    
    public partial class SupplierLogin : Form
    {
        
        public static int SID;
        public SupplierLogin()
        {
            InitializeComponent();
        }

        private void btnSupplierLogin_Click(object sender, EventArgs e)
        {
            Operations op = new Operations();
            int Sid=Convert.ToInt32(txtSupUserName.Text);
            string Spass=txtSupPassword.Text;
            bool auth = op.authSupplier(Sid, Spass);
            if (auth)
            {
                SID = Sid;
                Supplier sup = new Supplier();
                sup.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Credentials");
                txtSupUserName.Text = "";
                txtSupPassword.Text = "";
                txtSupUserName.Focus();
            }
            
        }

   
    }
}
