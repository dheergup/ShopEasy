﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SE.Entity;
using SE.Exception;
using SE.DAL;

namespace SE.PL
{
    public partial class Admin : Form
    {
        
        
       
        public Admin()
        {
            InitializeComponent();
        }

        private void LinklblLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminLogin al = new AdminLogin();
            al.Show();
            this.Hide();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            
            try
            {
                Operations op = new Operations();
                txtSID.Text = op.supplierID().ToString();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnAddSupplier_Click(object sender, EventArgs e)
        {
            Supplier supplier = new Supplier();
            
            //sp.SupplierID = Convert.ToInt32(txtSID.Text);
            //sp.CompanyName = txtCNAme.Text;
            //sp.Address1 = txtAddress1.Text;
            //sp.Address2 = txtAddress2.Text;
            //sp.City = txtCity.Text;
            //sp.State = cmbState.SelectedValue.ToString();
            //sp.PostalCode = txtPincode.Text;
            //sp.MobileNo = txtMobNo.Text;
            //sp.EmailId = txtEmailID.Text;
            //sp.Website = txtWeb.Text;
            //sp.Ranking = Convert.ToInt32(txtRank.Text);
            //sp.Note = txtNote.Text;
            //sp.Password = txtPassword.Text;

            try
            {   
                Operations op = new Operations();
                //op.AddSupplier(sp);
      
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnViewProducts_Click(object sender, EventArgs e)
        {
            Operations op = new Operations();

            grdViewProducts.DataSource = op.viewProduct();
        }

        private void btnViewSuppliers_Click(object sender, EventArgs e)
        {
            Operations op = new Operations();
            grdViewSuppliers.DataSource = op.viewSupplier();
        }

        private void btnViewOrders_Click(object sender, EventArgs e)
        {
            Operations op = new Operations();
            grdViewOrders.DataSource = op.viewOrder();
        }

        private void btnViewCustomers_Click(object sender, EventArgs e)
        {
            Operations op = new Operations();
            grdViewCustomers.DataSource = op.viewCustomer();
        }
    }
}
